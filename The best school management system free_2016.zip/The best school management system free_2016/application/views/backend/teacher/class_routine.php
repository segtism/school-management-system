<style type="text/css">
<!--
.style2 {color: #990000}
.style3 {font-size: 18px}
-->
</style>
<p align="center" class="style3"><strong>Disabled in Basic Version</strong></p>
<p align="center" class="style3"><strong><a href="www.optimumlinkup.com.ng" target="_blank" class="style2"><u>Upgrade</u></a> to full version for just 30$ only. <u>100% Source Code</u> <a href="www.optimumlinkup.com.ng" target="_blank"><u><span class="style2">www.Optimum Linkup.com.ng</span> </u></a></strong></p>
<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<div align="center">
  <input type="hidden" name="cmd" value="_s-xclick">
  <input type="hidden" name="hosted_button_id" value="4BKA5ZHWXARDU">
</div>
<img alt="" border="0" src="https://www.paypalobjects.com/en_GB/i/scr/pixel.gif" width="1" height="1">
</form>
<img src="uploads/images/teacher/classroutine_teacher.PNG" width="1037" height="601" />